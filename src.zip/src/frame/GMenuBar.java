package frame;

import javax.swing.JMenuBar;

import menus.GEditMenu;
import menus.GFileMenu;
import menus.GgraphicMenu;

public class GMenuBar extends JMenuBar {

	private static final long serialVersionUID = 1L;

	// component 
	private GFileMenu fileMenu;
	private GEditMenu editMenu;
	private GgraphicMenu graphicMenu; 
	
	// associations
	private GDrawingPanel drawingPanel;
	
	public GMenuBar() {
		this.fileMenu = new GFileMenu();
		this.editMenu = new GEditMenu();
		this.graphicMenu = new GgraphicMenu();

		this.add(this.fileMenu);
		this.add(this.editMenu);
		this.add(this.graphicMenu);
		
	}

	public void initialize() {
		// TODO Auto-generated method stub
	}

	public void associate(GDrawingPanel gDrawingPanel) {
		this.drawingPanel = gDrawingPanel;
	}
}
