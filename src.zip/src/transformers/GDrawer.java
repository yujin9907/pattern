package transformers;

import shapes.GShape;


// 구현코드 못 봄
public class GDrawer extends GTransformer {

	public GDrawer(GShape shape) {
		super();
	}

}
